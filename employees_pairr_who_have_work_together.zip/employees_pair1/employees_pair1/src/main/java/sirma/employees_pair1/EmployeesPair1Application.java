package sirma.employees_pair1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesPair1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesPair1Application.class, args);
	}

}
