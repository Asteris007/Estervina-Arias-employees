package sirma.employees_pair1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesPair1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
